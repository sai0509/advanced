package com.bank;

public interface ClientUserService {

	public String login(User user);

}
